# Airline IKARUS website

  Created by: Anastasia Kassari
  
  Date created: April 2017
  
  Info: An airline website created for an undergraduate project in web designing class. 
This airline company does not exist. Any resemblance to existing companies, services and products is
entirely coincidental.

  Requirements: All graphical interface must be created with HTML and CSS only (not Javascript).
