# bookmymovie
A simple movie ticket booking system made in PHP and MySQL
